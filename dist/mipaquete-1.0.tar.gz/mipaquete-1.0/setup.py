#modulo de python para esta tarea "setup tools". importamos setup
from setuptools import setup

#llamamos esa función
setup(
    #cualquier nombre
    name='mipaquete',
    #cualquier versión
    version='1.0',
    #cualquier descripción
    description='mi primer paquete redis',
    #cualquier autor
    author='Franco',
    #paquetes que querés
    packages=['paquete'],
)
