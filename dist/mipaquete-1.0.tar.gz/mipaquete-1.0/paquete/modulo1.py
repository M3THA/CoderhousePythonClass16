def funcion_modulo1():
    print("Hola estoy en mi paquete")